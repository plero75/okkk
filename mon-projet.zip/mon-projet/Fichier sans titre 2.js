 function setOpenAIKey() {
  PropertiesService.getScriptProperties().setProperty('OPENAI_API_KEY', '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');
}

function askChatGPT(prompt) {
  var apiKey = PropertiesService.getScriptProperties().getProperty('OPENAI_API_KEY');
  if (!apiKey) {
    throw new Error("Clé OPENAI_API_KEY introuvable. Lance d'abord setOpenAIKey().");
  }

  var url = 'https://api.openai.com/v1/responses';

  var payload = {
    model: 'gpt-4.1-mini',
    input: prompt
  };

  var options = {
    method: 'post',
    contentType: 'application/json',
    headers: {
      Authorization: 'Bearer ' + apiKey
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  var response = UrlFetchApp.fetch(url, options);
  var code = response.getResponseCode();
  var text = response.getContentText();

  if (code < 200 || code >= 300) {
    throw new Error('Erreur OpenAI (' + code + ') : ' + text);
  }

  var json = JSON.parse(text);
  return json.output_text || text;
}

function testChatGPT() {
  var reponse = askChatGPT("Écris une phrase d'accueil chic et chaleureuse pour un événement à Vincennes.");
  Logger.log(reponse);
}

function writeChatGPTInSheet() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var prompt = sheet.getRange("A1").getValue();
  var reponse = askChatGPT(prompt);
  sheet.getRange("B1").setValue(reponse);
}

function syncEnghien() { runAllForSite_("ENGHIEN"); }
function syncVincennes() { runAllForSite_("VINCENNES"); }

function syncAllSites() {
  runAllForSite_("ENGHIEN");
  runAllForSite_("VINCENNES");
}

function dashboardEnghien() { genererDashboard_("ENGHIEN"); }
function dashboardVincennes() { genererDashboard_("VINCENNES"); }

function conflitsEnghien() { verifierConflits_("ENGHIEN"); }
function conflitsVincennes() { verifierConflits_("VINCENNES"); }

function rapportMensuelCourantEnghien() {
  const now = new Date();
  rapportMensuel_("ENGHIEN", now.getFullYear(), now.getMonth() + 1);
}

function rapportMensuelCourantVincennes() {
  const now = new Date();
  rapportMensuel_("VINCENNES", now.getFullYear(), now.getMonth() + 1);
}

function rapportAnnuelCourantEnghien() {
  rapportAnnuel_("ENGHIEN", new Date().getFullYear());
}

function rapportAnnuelCourantVincennes() {
  rapportAnnuel_("VINCENNES", new Date().getFullYear());
}

// =======================
// OUTILS GÉNÉRAUX
// =======================

function getSpreadsheet_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function getSiteConfig_(siteKey) {
  const cfg = SITES[siteKey];
  if (!cfg) throw new Error("Site inconnu : " + siteKey);
  return cfg;
}

function ensureSheetByName_(name) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  return sh;
}

function getPlanningSheet_(siteKey) {
  return ensureSheetByName_(getSiteConfig_(siteKey).sheetName);
}

function getLogSheet_(siteKey) {
  const sh = ensureSheetByName_(getSiteConfig_(siteKey).logSheetName);
  if (sh.getLastRow() === 0) {
    sh.appendRow([
      "Horodatage",
      "Action",
      "Date",
      "Heure",
      "Événement",
      "Type",
      "ID_TECH",
      "Détail"
    ]);
  }
  return sh;
}

function getDashboardSheet_(siteKey) {
  return ensureSheetByName_(getSiteConfig_(siteKey).dashboardSheetName);
}

function getAlertsSheet_(siteKey) {
  return ensureSheetByName_(getSiteConfig_(siteKey).alertsSheetName);
}

function normalizeText_(str) {
  return String(str || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

function cleanText_(str) {
  return String(str || "").replace(/\s+/g, " ").trim();
}

function cleanHtml_(str) {
  return String(str || "").replace(/<\/?[^>]+(>|$)/g, "");
}

function formatDayKey_(date) {
  return Utilities.formatDate(date, TZ, "yyyyMMdd");
}

function formatDateKey_(date) {
  return Utilities.formatDate(date, TZ, "yyyy-MM-dd");
}

function formatDateFr_(date) {
  return Utilities.formatDate(date, TZ, "dd/MM/yyyy");
}

function formatMonthKey_(date) {
  return Utilities.formatDate(date, TZ, "yyyy-MM");
}

function formatWeekKey_(date) {
  return Utilities.formatDate(date, TZ, "YYYY-'S'ww");
}

function columnToLetter_(column) {
  let temp = "";
  let letter = "";
  while (column > 0) {
    temp = (column - 1) % 26;
    letter = String.fromCharCode(temp + 65) + letter;
    column = (column - temp - 1) / 26;
  }
  return letter;
}

function parseDateFlexible_(value) {
  if (value instanceof Date) return new Date(value);

  const s = String(value || "").trim();
  if (!s) return null;

  const mIso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (mIso) return new Date(Number(mIso[1]), Number(mIso[2]) - 1, Number(mIso[3]));

  const mFr = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (mFr) return new Date(Number(mFr[3]), Number(mFr[2]) - 1, Number(mFr[1]));

  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function getSyncRange_() {
  const year = new Date().getFullYear();
  return {
    year: year,
    start: new Date(year, 0, 1),
    end: new Date(year, 11, 31, 23, 59, 59)
  };
}

function getYearRange_(year) {
  return {
    start: new Date(year, 0, 1),
    end: new Date(year, 11, 31, 23, 59, 59)
  };
}

function getMonthRange_(year, month) {
  return {
    start: new Date(year, month - 1, 1),
    end: new Date(year, month, 0, 23, 59, 59)
  };
}

// =======================
// TEST AGENDAS
// =======================

function testerTousLesAgendas_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheetName = "TEST_AGENDAS";
  let sh = ss.getSheetByName(sheetName);

  if (!sh) {
    sh = ss.insertSheet(sheetName);
  } else {
    sh.clear();
  }

  const headers = [
    "Site",
    "Type agenda",
    "ID agenda",
    "Test CalendarApp",
    "Test Calendar API",
    "Diagnostic",
    "Détail erreur"
  ];

  sh.getRange(1, 1, 1, headers.length).setValues([headers]);

  const results = [];
  const start = new Date();
  const end = new Date(start.getTime() + 7 * 24 * 60 * 60 * 1000);

  Object.keys(SITES).forEach(function(siteKey) {
    const cfg = SITES[siteKey];

    [
      { type: "Courses", id: cfg.calendarCourses },
      { type: "Événements", id: cfg.calendarEvents }
    ].forEach(function(item) {
      const calendarId = String(item.id || "").trim();

      let calAppStatus = "NON TESTÉ";
      let apiStatus = "NON TESTÉ";
      let diagnostic = "";
      let detail = "";

      if (!calendarId) {
        calAppStatus = "KO";
        apiStatus = "KO";
        diagnostic = "ID agenda vide";
        detail = "Aucun identifiant renseigné dans la configuration.";
      } else {
        try {
          const cal = CalendarApp.getCalendarById(calendarId);
          calAppStatus = cal ? "OK" : "KO";
        } catch (e) {
          calAppStatus = "KO";
          detail += "[CalendarApp] " + e.message + " ";
        }

        try {
          const res = Calendar.Events.list(calendarId, {
            timeMin: start.toISOString(),
            timeMax: end.toISOString(),
            singleEvents: true,
            maxResults: 5
          });
          apiStatus = "OK";
          detail += "[API] Lecture OK, " + ((res.items || []).length) + " événement(s) sur 7 jours. ";
        } catch (e) {
          apiStatus = "KO";
          detail += "[API] " + e.message + " ";
        }

        if (calAppStatus === "OK" && apiStatus === "OK") {
          diagnostic = "OK";
        } else if (calAppStatus === "KO" && apiStatus === "KO") {
          diagnostic = "Agenda introuvable, ID faux ou non partagé";
        } else if (calAppStatus === "OK" && apiStatus === "KO") {
          diagnostic = "CalendarApp OK, API KO : vérifier l’activation de Google Calendar API";
        } else if (calAppStatus === "KO" && apiStatus === "OK") {
          diagnostic = "Cas atypique, vérifier les autorisations du projet";
        }
      }

      results.push([
        cfg.label,
        item.type,
        calendarId,
        calAppStatus,
        apiStatus,
        diagnostic,
        detail.trim()
      ]);
    });
  });

  if (results.length) {
    sh.getRange(2, 1, results.length, headers.length).setValues(results);
  }

  sh.autoResizeColumns(1, headers.length);
  sh.getRange(1, 1, 1, headers.length).setFontWeight("bold");
  sh.setFrozenRows(1);

  SpreadsheetApp.getUi().alert("Test des agendas terminé.\n\nConsulte l’onglet TEST_AGENDAS.");
}

// =======================
// EXTRACTIONS DESCRIPTION
// =======================

function getProjectManager_(event) {
  const descOriginale = cleanHtml_(event.description || "");
  if (!descOriginale.trim()) return "";

  const patterns = [
    /(?:^|\n|\r)\s*(?:responsables?|resp)(?:\s*setf)?\s*[:\-]?\s*(.+)/i,
    /(?:^|\n|\r)\s*(?:gestion|gestionnaire)\s*[:\-]?\s*(.+)/i,
    /(?:^|\n|\r)\s*(?:chef de projet|cp)\s*[:\-]?\s*(.+)/i,
    /(?:^|\n|\r)\s*(?:referent|référent)\s*[:\-]?\s*(.+)/i
  ];

  for (let i = 0; i < patterns.length; i++) {
    const match = descOriginale.match(patterns[i]);
    if (match && match[1]) {
      return cleanText_(
        match[1]
          .split(/\n|\r/)[0]
          .replace(/\s*\|\s*.*/, "")
      );
    }
  }

  return "";
}

function getB2BFlag_(event) {
  const desc = String(event.description || "").toLowerCase();
  if (!desc) return "B2C";
  if (desc.includes("b2b")) return "B2B";
  if (desc.includes("b2c")) return "B2C";
  return "B2C";
}

function getPaxFromDescription_(event) {
  const desc = cleanHtml_(event.description || "");
  if (!desc) return "";
  const lower = desc.toLowerCase();

  const patterns = [
    /\b(?:pax|participants?|pers|personnes?|jauge)\s*[:\-]?\s*(\d{1,5})/i,
    /(\d{1,5})\s*(?:pax|participants?|pers|personnes?|jauge)/i
  ];

  for (let i = 0; i < patterns.length; i++) {
    const m = lower.match(patterns[i]);
    if (m && m[1]) {
      const n = parseInt(m[1], 10);
      if (!isNaN(n)) return n;
    }
  }
  return "";
}

// =======================
// CALENDAR API
// =======================

function getAllEventsRaw_(calendarId, start, end) {
  const items = [];
  let pageToken = null;

  do {
    const res = Calendar.Events.list(calendarId, {
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: true,
      showDeleted: false,
      maxResults: 2500,
      pageToken: pageToken
    });

    if (res.items && res.items.length) {
      for (let i = 0; i < res.items.length; i++) items.push(res.items[i]);
    }

    pageToken = res.nextPageToken;
  } while (pageToken);

  return items;
}

function getAllEventsForSite_(siteKey, start, end) {
  const cfg = getSiteConfig_(siteKey);
  return {
    courseEvents: getAllEventsRaw_(cfg.calendarCourses, start, end),
    eventEvents: getAllEventsRaw_(cfg.calendarEvents, start, end)
  };
}

// =======================
// ESPACES / RESSOURCES
// =======================

function getDisplayResourceLabel_(raw) {
  const s = String(raw || "").trim();

  const patterns = [
    /SALON HEMINGWAY/i,
    /GRAND HALL/i,
    /HALL DES BALANCES/i,
    /LA ROTONDE/i,
    /BORD DE PISTE/i,
    /LES EXT[ÉE]RIEURS/i,
    /PARKING DES VANS/i,
    /PARKING GRAND PUBLIC/i,
    /PARKING GRAN D PUBLIC/i,
    /PARKING PROPRIETAIRE/i,
    /RESTAURANT PANORAMIQUE/i,
    /LA TERRASSE/i,
    /TRIBUNES?/i,
    /SALLE DES COMMISSAIRES/i,
    /SALLE DES FAIENCES/i,
    /ESPACE LOUNGE DES BALAN/i,
    /LES ÉCURIES/i,
    /LES ECURIES/i
  ];

  for (let i = 0; i < patterns.length; i++) {
    const m = s.match(patterns[i]);
    if (m) {
      return m[0]
        .replace(/GRAN D/i, "GRAND")
        .replace(/EXTERIEURS/i, "EXTÉRIEURS")
        .replace(/ECURIES/i, "ÉCURIES")
        .toUpperCase();
    }
  }

  return s
    .replace(/^\([^)]*\)-/i, "")
    .replace(/Hippodrome (Enghien-Soisy|Paris-Vincennes)-?/i, "")
    .replace(/\(\d+\)/g, "")
    .replace(/\b(RDC|1|2|3)-/g, "")
    .replace(/Intérieur|Extérieur/gi, "")
    .replace(/-+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

function extractResourcesFromEvents_(events) {
  const map = new Map();

  for (let i = 0; i < events.length; i++) {
    const attendees = events[i].attendees || [];

    for (let g = 0; g < attendees.length; g++) {
      const attendee = attendees[g];
      if (attendee.resource !== true) continue;

      const raw = String(attendee.displayName || attendee.email || "").trim();
      const norm = normalizeText_(raw);
      if (!norm) continue;

      if (!map.has(norm)) {
        map.set(norm, getDisplayResourceLabel_(raw));
      }
    }
  }

  return map;
}

function getDynamicSpaces_(courseEvents, eventEvents) {
  const allEvents = courseEvents.concat(eventEvents);
  const map = extractResourcesFromEvents_(allEvents);

  return Array.from(map.entries())
    .map(function(entry) {
      return { norm: entry[0], label: entry[1] };
    })
    .sort(function(a, b) {
      return a.label.localeCompare(b.label, "fr", { sensitivity: "base" });
    });
}

function buildSpaceIndex_(siteKey, spaces) {
  const index = {};
  const fixedColsCount = getFixedColsCount_(siteKey);

  for (let i = 0; i < spaces.length; i++) {
    index[spaces[i].norm] = fixedColsCount + i;
  }
  return index;
}

function getEventResourceNorms_(event) {
  const norms = [];
  const seen = {};

  const attendees = event.attendees || [];
  for (let i = 0; i < attendees.length; i++) {
    const attendee = attendees[i];
    if (attendee.resource !== true) continue;

    const norm = normalizeText_(attendee.displayName || attendee.email);
    if (!norm || seen[norm]) continue;

    seen[norm] = true;
    norms.push(norm);
  }

  return norms;
}

// =======================
// COURSES
// =======================

function detectCourseSessionType_(event, startDate) {
  const title = String(event.summary || "").toUpperCase();

  if (title.includes("SEMI-NOCTURNE") || title.includes("SEMI NOCTURNE")) return "Semi-nocturne";
  if (title.includes("NOCTURNE")) return "Nocturne";
  if (title.includes("DIURNE")) return "Diurne";

  const hour = Number(Utilities.formatDate(startDate, TZ, "H"));
  if (hour >= 20) return "Nocturne";
  if (hour >= 17) return "Semi-nocturne";
  return "Diurne";
}

function buildCourseTimeLabel_(event, startDate, endDate, isAllDay) {
  if (isAllDay) return "";
  const typeLabel = detectCourseSessionType_(event, startDate);
  const hDebut = Utilities.formatDate(startDate, TZ, "HH:mm");
  const hFin = Utilities.formatDate(endDate, TZ, "HH:mm");
  return typeLabel + " | " + hDebut + " - " + hFin;
}

function getSiteLabelForReference_(siteKey) {
  return siteKey === "ENGHIEN" ? "Enghien" : "Vincennes";
}

function getGroupe1CoursesForDate_(siteKey, dateObj) {
  const siteLabel = getSiteLabelForReference_(siteKey);
  const dateKey = Utilities.formatDate(dateObj, TZ, "yyyy-MM-dd");

  return GROUPE_1_REFERENCE
    .filter(function(item) {
      return item.hippodrome === siteLabel && item.date2026 === dateKey;
    })
    .map(function(item) {
      return item.course;
    });
}

function getGroupe_1CoursesForDateSafe_(siteKey, dateObj) {
  try {
    return getGroupe1CoursesForDate_(siteKey, dateObj);
  } catch (e) {
    return [];
  }
}

function getCoursePhareLabel_(siteKey, dateObj) {
  const courses = getGroupe_1CoursesForDateSafe_(siteKey, dateObj);
  return courses.length ? courses.join(" | ") : "";
}

function getCourseLabelForPlanning_(siteKey, dateObj) {
  const coursePhare = getCoursePhareLabel_(siteKey, dateObj);
  return coursePhare || "Réunion de courses";
}

function isCoursePhare_(label) {
  const txt = String(label || "").trim();
  if (!txt) return false;

  return GROUPE_1_REFERENCE.some(function(item) {
    return item.course === txt;
  });
}

function isCourseRow_(siteKey, eventText, typeValue) {
  return String(typeValue || "").trim() === "Course";
}

// =======================
// CONSTRUCTION DU PLANNING
// =======================

function parseEventDates_(event) {
  const isAllDay = !!(event.start && event.start.date && !event.start.dateTime);

  let startDate = null;
  let endDate = null;

  if (isAllDay) {
    startDate = new Date(event.start.date);
    endDate = new Date(event.end.date);
    endDate = new Date(endDate.getTime() - 86400000);
  } else {
    startDate = new Date(event.start.dateTime);
    endDate = new Date(event.end.dateTime);
  }

  return { startDate: startDate, endDate: endDate, isAllDay: isAllDay };
}

function createBaseRowsByDay_(year) {
  const rows = [];
  for (let d = new Date(year, 0, 1); d <= new Date(year, 11, 31); d.setDate(d.getDate() + 1)) {
    const dateObj = new Date(d);
    rows.push({
      dayKey: formatDayKey_(dateObj),
      dateObj: dateObj,
      items: []
    });
  }
  return rows;
}

function getFixedHeaders_(siteKey) {
  return [
    "Date N",
    "Evénement + Heure",
    "Gestion",
    "Type",
    "PAX"
  ];
}

function getFixedColsCount_(siteKey) {
  return getFixedHeaders_(siteKey).length;
}

function getGestionColumnIndex_(siteKey) {
  return 2;
}

function getTypeColumnIndex_(siteKey) {
  return 3;
}

function getHeaders_(siteKey, spaces) {
  return getFixedHeaders_(siteKey).concat(
    spaces.map(function(s) { return s.label; }),
    [TRAILING_HEADER]
  );
}

function buildEventRow_(siteKey, event, type, dateObj, spacesCount, spaceIndex) {
  const parsed = parseEventDates_(event);
  const startDate = parsed.startDate;
  const endDate = parsed.endDate;
  const isAllDay = parsed.isAllDay;

  const fixedColsCount = getFixedColsCount_(siteKey);
  const row = new Array(fixedColsCount + spacesCount + 1).fill("");

  const resourceNorms = getEventResourceNorms_(event);
  const manager = getProjectManager_(event);
  const b2b = getB2BFlag_(event);
  const pax = getPaxFromDescription_(event);

  const label = (type === "course")
    ? getCourseLabelForPlanning_(siteKey, dateObj)
    : String(event.summary || "");

  const heure = (type === "course")
    ? buildCourseTimeLabel_(event, startDate, endDate, isAllDay)
    : "";

  row[0] = new Date(dateObj);
  row[1] = heure ? (label + " | " + heure) : label;
  row[2] = manager;
  row[3] = (type === "course") ? "Course" : b2b;
  row[4] = pax;

  for (let i = 0; i < resourceNorms.length; i++) {
    const col = spaceIndex[resourceNorms[i]];
    if (col !== undefined) row[col] = "X";
  }

  row[row.length - 1] =
    (event.id || event.iCalUID || "NO_ID") + "_" +
    Utilities.formatDate(dateObj, TZ, "yyyyMMdd");

  return row;
}

function appendEventsToDays_(siteKey, events, type, dayIndex, spacesCount, spaceIndex) {
  for (let i = 0; i < events.length; i++) {
    const event = events[i];
    const parsed = parseEventDates_(event);
    const startDate = parsed.startDate;
    const endDate = parsed.endDate;

    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const key = formatDayKey_(d);
      const day = dayIndex[key];
      if (!day) continue;
      day.items.push(buildEventRow_(siteKey, event, type, new Date(d), spacesCount, spaceIndex));
    }
  }
}

function buildCalendarRowsAndEntries_(siteKey, courseEvents, eventEvents, spaces, year) {
  const baseDays = createBaseRowsByDay_(year);
  const dayIndex = {};
  const spaceIndex = buildSpaceIndex_(siteKey, spaces);
  const fixedColsCount = getFixedColsCount_(siteKey);

  for (let i = 0; i < baseDays.length; i++) {
    dayIndex[baseDays[i].dayKey] = baseDays[i];
  }

  appendEventsToDays_(siteKey, courseEvents, "course", dayIndex, spaces.length, spaceIndex);
  appendEventsToDays_(siteKey, eventEvents, "event", dayIndex, spaces.length, spaceIndex);

  const rows = [];
  const entries = {};

  for (let i = 0; i < baseDays.length; i++) {
    const day = baseDays[i];

    if (!day.items.length) {
      const emptyRow = new Array(fixedColsCount + spaces.length + 1).fill("");
      emptyRow[0] = day.dateObj;
      emptyRow[emptyRow.length - 1] = "DAY_" + day.dayKey;
      rows.push(emptyRow);

      entries[emptyRow[emptyRow.length - 1]] = {
        date: formatDateKey_(day.dateObj),
        evenement: "",
        heure: "",
        type: "",
        gestion: "",
        b2b: "",
        pax: "",
        spaces: []
      };
      continue;
    }

    day.items.sort(function(a, b) {
      const dateDiff = new Date(a[0]).getTime() - new Date(b[0]).getTime();
      if (dateDiff !== 0) return dateDiff;

      const labelA = String(a[1] || "");
      const labelB = String(b[1] || "");
      return labelA.localeCompare(labelB);
    });

    for (let j = 0; j < day.items.length; j++) {
      const row = day.items[j];
      rows.push(row);

      const id = row[row.length - 1];
      const spacesForEntry = [];

      for (let c = fixedColsCount; c < row.length - 1; c++) {
        if (row[c] === "X") {
          spacesForEntry.push(normalizeText_(spaces[c - fixedColsCount].label));
        }
      }

      entries[id] = {
        date: formatDateKey_(row[0]),
        evenement: String(row[1] || ""),
        heure: "",
        type: String(row[3] || ""),
        gestion: String(row[2] || ""),
        b2b: String(row[3] === "Course" ? "" : row[3] || ""),
        pax: String(row[4] || ""),
        spaces: spacesForEntry
      };
    }
  }

  rows.sort(function(a, b) {
    const dateDiff = new Date(a[0]).getTime() - new Date(b[0]).getTime();
    if (dateDiff !== 0) return dateDiff;
    return String(a[1] || "").localeCompare(String(b[1] || ""));
  });

  return { rows: rows, entries: entries };
}

// =======================
// LECTURE / LOG DELTA
// =======================

function rebuildHeaders_(siteKey, sheet, spaces) {
  sheet.clear();
  const headers = getHeaders_(siteKey, spaces);
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.setFrozenRows(1);
  sheet.hideColumn(sheet.getRange(1, headers.length));
}

function readExistingEntries_(siteKey, sheet) {
  const result = {};

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return result;

  const headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  const values = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();

  const fixedColsCount = getFixedColsCount_(siteKey);
  const dateIdx = headers.indexOf("Date N");
  const eventIdx = headers.indexOf("Evénement + Heure");
  const gestionIdx = headers.indexOf("Gestion");
  const typeIdx = headers.indexOf("Type");
  const paxIdx = headers.indexOf("PAX");
  const idIdx = headers.indexOf("ID_TECH");

  if (idIdx === -1) return result;

  const dynamicHeaders = headers.slice(fixedColsCount, idIdx);

  for (let i = 0; i < values.length; i++) {
    const row = values[i];
    const id = row[idIdx];
    if (!id) continue;

    const spaces = [];
    for (let j = 0; j < dynamicHeaders.length; j++) {
      if (row[fixedColsCount + j] === "X") {
        spaces.push(normalizeText_(dynamicHeaders[j]));
      }
    }

    result[id] = {
      date: row[dateIdx] instanceof Date ? formatDateKey_(row[dateIdx]) : String(row[dateIdx] || ""),
      evenement: String(row[eventIdx] || ""),
      heure: "",
      type: String((typeIdx > -1 ? row[typeIdx] : "") || ""),
      gestion: String((gestionIdx > -1 ? row[gestionIdx] : "") || ""),
      b2b: String((typeIdx > -1 && row[typeIdx] !== "Course" ? row[typeIdx] : "") || ""),
      pax: String((paxIdx > -1 ? row[paxIdx] : "") || ""),
      spaces: spaces
    };
  }

  return result;
}

function stringifyEntry_(entry) {
  return JSON.stringify({
    date: entry.date || "",
    evenement: entry.evenement || "",
    heure: entry.heure || "",
    type: entry.type || "",
    gestion: entry.gestion || "",
    b2b: entry.b2b || "",
    pax: entry.pax || "",
    spaces: (entry.spaces || []).slice().sort()
  });
}

function buildLogEntry_(action, rowOrEntry, detail) {
  let dateValue = "";
  let heureValue = "";
  let eventValue = "";
  let typeValue = "";
  let idValue = "";

  if (Array.isArray(rowOrEntry)) {
    dateValue = rowOrEntry[0] || "";
    eventValue = rowOrEntry[1] || "";
    heureValue = "";
    typeValue = rowOrEntry[3] || "";
    idValue = rowOrEntry[rowOrEntry.length - 1] || "";
  } else {
    dateValue = rowOrEntry.date || "";
    eventValue = rowOrEntry.evenement || "";
    heureValue = rowOrEntry.heure || "";
    typeValue = rowOrEntry.type || "";
    idValue = rowOrEntry.id || "";
  }

  return [
    new Date(),
    action,
    dateValue,
    heureValue,
    eventValue,
    typeValue,
    idValue,
    detail || ""
  ];
}

function buildUpdateDetail_(oldEntry, newEntry) {
  const changes = [];

  if ((oldEntry.evenement || "") !== (newEntry.evenement || "")) {
    changes.push("événement: '" + (oldEntry.evenement || "") + "' → '" + (newEntry.evenement || "") + "'");
  }
  if ((oldEntry.type || "") !== (newEntry.type || "")) {
    changes.push("type: '" + (oldEntry.type || "") + "' → '" + (newEntry.type || "") + "'");
  }
  if ((oldEntry.gestion || "") !== (newEntry.gestion || "")) {
    changes.push("gestion: '" + (oldEntry.gestion || "") + "' → '" + (newEntry.gestion || "") + "'");
  }
  if ((oldEntry.b2b || "") !== (newEntry.b2b || "")) {
    changes.push("B2B/B2C: '" + (oldEntry.b2b || "") + "' → '" + (newEntry.b2b || "") + "'");
  }
  if ((oldEntry.pax || "") !== (newEntry.pax || "")) {
    changes.push("PAX: '" + (oldEntry.pax || "") + "' → '" + (newEntry.pax || "") + "'");
  }

  const oldSpaces = (oldEntry.spaces || []).slice().sort().join(", ");
  const newSpaces = (newEntry.spaces || []).slice().sort().join(", ");
  if (oldSpaces !== newSpaces) {
    changes.push("espaces: '" + oldSpaces + "' → '" + newSpaces + "'");
  }

  return changes.join(" | ");
}

function buildDeltaLogEntries_(oldEntries, newEntries) {
  const logs = [];
  const seen = {};

  for (const id in oldEntries) {
    seen[id] = true;

    if (!newEntries[id]) {
      logs.push(buildLogEntry_("SUPPRESSION", {
        date: oldEntries[id].date,
        evenement: oldEntries[id].evenement,
        heure: oldEntries[id].heure,
        type: oldEntries[id].type,
        id: id
      }, ""));
      continue;
    }

    if (stringifyEntry_(oldEntries[id]) !== stringifyEntry_(newEntries[id])) {
      logs.push(buildLogEntry_("MODIFICATION", {
        date: newEntries[id].date,
        evenement: newEntries[id].evenement,
        heure: newEntries[id].heure,
        type: newEntries[id].type,
        id: id
      }, buildUpdateDetail_(oldEntries[id], newEntries[id])));
    }
  }

  for (const id in newEntries) {
    if (seen[id]) continue;

    logs.push(buildLogEntry_("AJOUT", {
      date: newEntries[id].date,
      evenement: newEntries[id].evenement,
      heure: newEntries[id].heure,
      type: newEntries[id].type,
      id: id
    }, ""));
  }

  return logs;
}

function writeSyncLog_(siteKey, entries) {
  if (!entries || !entries.length) return;
  const logSheet = getLogSheet_(siteKey);
  logSheet.getRange(logSheet.getLastRow() + 1, 1, entries.length, entries[0].length)
    .setValues(entries);
}

// =======================
// SYNCHRO PRINCIPALE
// =======================

function synchroniserCalendriersVersFeuille(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  const oldEntries = readExistingEntries_(siteKey, sheet);

  const syncRange = getSyncRange_();
  const allEvents = getAllEventsForSite_(siteKey, syncRange.start, syncRange.end);

  const spaces = getDynamicSpaces_(allEvents.courseEvents, allEvents.eventEvents);
  rebuildHeaders_(siteKey, sheet, spaces);

  const built = buildCalendarRowsAndEntries_(
    siteKey,
    allEvents.courseEvents,
    allEvents.eventEvents,
    spaces,
    syncRange.year
  );

  const headers = getHeaders_(siteKey, spaces);
  const expectedCols = headers.length;
  const actualCols = built.rows.length ? built.rows[0].length : 0;

  Logger.log("=== SYNCHRO " + siteKey + " ===");
  Logger.log("Headers count = " + expectedCols);
  Logger.log("Rows count = " + built.rows.length);
  Logger.log("Row length = " + actualCols);

  if (built.rows.length) {
    if (expectedCols !== actualCols) {
      Logger.log("HEADERS DETAIL = " + JSON.stringify(headers));
      Logger.log("ROW DETAIL = " + JSON.stringify(built.rows[0]));
      throw new Error(
        "Mismatch colonnes pour " + siteKey +
        " : headers=" + expectedCols +
        " / rows=" + actualCols
      );
    }

    sheet.getRange(2, 1, built.rows.length, actualCols).setValues(built.rows);
  }

  appliquerMiseEnPage(siteKey);
  nettoyerAffichageDates_(siteKey);
  masquerLignesPassees_(siteKey);
  styliserCoursesPhares_(siteKey);

  const logEntries = buildDeltaLogEntries_(oldEntries, built.entries);
  writeSyncLog_(siteKey, logEntries);

  return {
    site: getSiteConfig_(siteKey).label,
    rows: built.rows.length,
    spaces: spaces.length,
    added: logEntries.filter(function(r) { return r[1] === "AJOUT"; }).length,
    updated: logEntries.filter(function(r) { return r[1] === "MODIFICATION"; }).length,
    deleted: logEntries.filter(function(r) { return r[1] === "SUPPRESSION"; }).length
  };
}

// =======================
// MASQUAGE / AFFICHAGE
// =======================

function masquerLignesPassees_(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return;

  sheet.showRows(2, lastRow - 1);

  const idTechCol = lastCol;
  const ids = sheet.getRange(2, idTechCol, lastRow - 1, 1).getValues();

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const rowsToHide = [];

  for (let i = 0; i < ids.length; i++) {
    const row = i + 2;
    const id = String(ids[i][0] || "").trim();
    if (!id) continue;

    const match = id.match(/(\d{8})$/);
    if (!match) continue;

    const ymd = match[1];
    const rowDate = new Date(
      Number(ymd.substring(0, 4)),
      Number(ymd.substring(4, 6)) - 1,
      Number(ymd.substring(6, 8))
    );
    rowDate.setHours(0, 0, 0, 0);

    if (rowDate < today) {
      rowsToHide.push(row);
    }
  }

  if (!rowsToHide.length) return;

  let start = rowsToHide[0];
  let prev = rowsToHide[0];

  for (let i = 1; i < rowsToHide.length; i++) {
    const current = rowsToHide[i];

    if (current === prev + 1) {
      prev = current;
    } else {
      sheet.hideRows(start, prev - start + 1);
      start = current;
      prev = current;
    }
  }

  sheet.hideRows(start, prev - start + 1);
}

function masquerLignesPasseesTousSites_() {
  masquerLignesPassees_("ENGHIEN");
  masquerLignesPassees_("VINCENNES");
}

function afficherToutesLesLignes_(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  if (lastRow > 1) {
    sheet.showRows(2, lastRow - 1);
  }
}

function afficherToutesLesLignesTousSites_() {
  afficherToutesLesLignes_("ENGHIEN");
  afficherToutesLesLignes_("VINCENNES");
}

function nettoyerAffichageDates_(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  const lastRow = sheet.getLastRow();
  if (lastRow < 3) return;

  const range = sheet.getRange(2, 1, lastRow - 1, 1);
  const values = range.getValues();

  let previousDateKey = null;

  for (let i = 0; i < values.length; i++) {
    const cell = values[i][0];
    if (!(cell instanceof Date)) continue;

    const currentKey = Utilities.formatDate(cell, TZ, "yyyyMMdd");

    if (currentKey === previousDateKey) {
      values[i][0] = "";
    } else {
      previousDateKey = currentKey;
    }
  }

  range.setValues(values);
}

// =======================
// STYLISATION COURSES PHARES
// =======================

function styliserCoursesPhares_(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const values = sheet.getRange(2, 2, lastRow - 1, 1).getValues();

  for (let i = 0; i < values.length; i++) {
    const row = i + 2;
    const text = String(values[i][0] || "");
    if (!text) continue;

    const parts = text.split("|");
    const courseName = parts[0].trim();

    if (!isCoursePhare_(courseName)) {
      sheet.getRange(row, 2)
        .setFontFamily("Arial")
        .setFontStyle("normal")
        .setFontSize(11);
      continue;
    }

    const builder = SpreadsheetApp.newRichTextValue().setText(text);

    builder.setTextStyle(
      0,
      courseName.length,
      SpreadsheetApp.newTextStyle()
        .setFontFamily("Oswald")
        .setItalic(true)
        .setFontSize(10)
        .build()
    );

    builder.setTextStyle(
      courseName.length,
      text.length,
      SpreadsheetApp.newTextStyle()
        .setFontFamily("Arial")
        .setItalic(false)
        .setFontSize(11)
        .build()
    );

    sheet.getRange(row, 2).setRichTextValue(builder.build());
  }
}

// =======================
// MISE EN PAGE
// =======================

function appliquerMiseEnPage(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow === 0) return;

  const dataRange = sheet.getRange(1, 1, lastRow, lastCol);
  const fixedColsCount = getFixedColsCount_(siteKey);

  sheet.clearFormats();
  sheet.clearNotes();
  try { dataRange.breakApart(); } catch (e) {}

  dataRange
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setFontFamily("Arial")
    .setFontSize(11)
    .setFontWeight("normal");

  sheet.setFrozenRows(1);

  sheet.setColumnWidth(1, 170);
  sheet.setColumnWidth(2, 520);
  sheet.setColumnWidth(3, 180);
  sheet.setColumnWidth(4, 90);
  sheet.setColumnWidth(5, 80);

  const espaceStartCol = fixedColsCount + 1;
  const espaceCount = Math.max(0, lastCol - fixedColsCount - 1);

  for (let i = espaceStartCol; i < lastCol; i++) {
    sheet.setColumnWidth(i, 35);
  }

  sheet.setRowHeight(1, 36);
  sheet.getRange(1, 1, 1, lastCol)
    .setBackground("#ffffff")
    .setFontWeight("bold")
    .setWrap(true)
    .setHorizontalAlignment("center")
    .setVerticalAlignment("middle")
    .setTextRotation(0);

  if (espaceCount > 0) {
    sheet.getRange(1, espaceStartCol, 1, espaceCount)
      .setTextRotation(90)
      .setVerticalAlignment("middle")
      .setHorizontalAlignment("center")
      .setWrap(false);

    sheet.getRange(2, espaceStartCol, Math.max(1, lastRow - 1), espaceCount)
      .setWrap(false)
      .setVerticalAlignment("middle")
      .setHorizontalAlignment("center");
  }

  if (lastRow > 1) {
    sheet.getRange(1, 3, 1, 1).setBackground("#eeeeee");
    sheet.getRange(1, 4, 1, 1).setBackground("#e6f3ff");
    sheet.getRange(1, 5, 1, 1).setBackground("#f7f7d9");

    const dates = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const rangeListEvents = [];
    const rangeListCourses = [];
    const rangeListEmpty = [];

    const dateCounts = {};
    for (let i = 0; i < dates.length; i++) {
      if (dates[i][0] instanceof Date) {
        const key = formatDayKey_(dates[i][0]);
        dateCounts[key] = (dateCounts[key] || 0) + 1;
      }
    }

    const boldRows = [];
    const solidTopRows = [];
    const dottedTopRows = [];
    const lastColLetter = columnToLetter_(lastCol);

    let previousDayKey = null;

    for (let i = 0; i < dates.length; i++) {
      const row = i + 2;

      let currentDayKey = null;
      if (dates[i][0] instanceof Date) {
        currentDayKey = formatDayKey_(dates[i][0]);
      }

      const currentType = String(sheet.getRange(row, 4).getValue() || "").trim();
      const blockEndCol = 5;

      if (currentType === "Course") {
        rangeListCourses.push("A" + row + ":" + columnToLetter_(blockEndCol) + row);
      } else if (currentType === "B2B" || currentType === "B2C") {
        rangeListEvents.push("A" + row + ":" + columnToLetter_(blockEndCol) + row);
      } else {
        rangeListEmpty.push("A" + row + ":" + columnToLetter_(blockEndCol) + row);
      }

      if (currentDayKey && (dateCounts[currentDayKey] || 0) > 1) {
        boldRows.push("A" + row + ":" + lastColLetter + row);
      }

      if (i === 0 || currentDayKey !== previousDayKey) {
        solidTopRows.push("A" + row + ":" + lastColLetter + row);
      } else {
        dottedTopRows.push("A" + row + ":" + lastColLetter + row);
      }

      previousDayKey = currentDayKey;
    }

    if (rangeListEvents.length) {
      sheet.getRangeList(rangeListEvents).setBackground("#dff3ff");
    }
    if (rangeListCourses.length) {
      sheet.getRangeList(rangeListCourses).setBackground("#fff1cc");
    }
    if (rangeListEmpty.length) {
      sheet.getRangeList(rangeListEmpty).setBackground("white");
    }

    if (espaceCount > 0) {
      const espacesRange = sheet.getRange(2, espaceStartCol, lastRow - 1, espaceCount);
      espacesRange
        .setBackground("#f4f4f4")
        .setWrap(false)
        .setVerticalAlignment("middle")
        .setHorizontalAlignment("center");
    }

    sheet.getRange(2, 1, lastRow - 1, lastCol).setFontWeight("normal");
    if (boldRows.length) {
      sheet.getRangeList(boldRows).setFontWeight("bold");
    }

    sheet.getRange(2, 1, lastRow - 1, lastCol)
      .setBorder(false, null, false, false, false, false);

    if (solidTopRows.length) {
      sheet.getRangeList(solidTopRows).setBorder(
        true, null, null, null, null, null,
        "black",
        SpreadsheetApp.BorderStyle.SOLID
      );
    }

    if (dottedTopRows.length) {
      sheet.getRangeList(dottedTopRows).setBorder(
        true, null, null, null, null, null,
        "#999999",
        SpreadsheetApp.BorderStyle.DOTTED
      );
    }

    sheet.getRange(2, 1, lastRow - 1, 1).setNumberFormat('[$-fr]dddd d mmmm yyyy');
    sheet.getRange(2, 2, lastRow - 1, fixedColsCount - 1).setWrap(true);
  }

  if (espaceCount > 0) {
    for (let col = espaceStartCol; col < lastCol; col++) {
      sheet.getRange(1, col, lastRow, 1).setBorder(
        null,
        true,
        null,
        true,
        null,
        null,
        "black",
        SpreadsheetApp.BorderStyle.DOUBLE
      );
    }
  }

  dataRange.setBorder(
    true, true, true, true, null, null,
    "black",
    SpreadsheetApp.BorderStyle.SOLID
  );

  sheet.hideColumn(sheet.getRange(1, lastCol));
}

// =======================
// LECTURE DU PLANNING
// =======================

function readPlanningData_(siteKey) {
  const sheet = getPlanningSheet_(siteKey);
  if (!sheet) return { headers: [], rows: [] };

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 1) return { headers: [], rows: [] };

  const headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  const values = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, lastCol).getValues() : [];

  const rows = values.map(function(row) {
    const obj = {};
    for (let i = 0; i < headers.length; i++) obj[headers[i]] = row[i];
    return obj;
  });

  return { headers: headers, rows: rows };
}

function getDynamicSpaceHeadersFromSheet_(siteKey, headers) {
  const fixedColsCount = getFixedColsCount_(siteKey);
  const idIdx = headers.indexOf("ID_TECH");
  if (idIdx === -1) return [];
  return headers.slice(fixedColsCount, idIdx);
}

function filterRowsByDate_(rows, startDate, endDate) {
  return rows.filter(function(r) {
    const d = r["Date N"];
    if (!(d instanceof Date)) return false;
    return d >= startDate && d <= endDate;
  });
}

// =======================
// DASHBOARD
// =======================

function genererDashboard_(siteKey) {
  const sh = getDashboardSheet_(siteKey);
  sh.clear();

  const data = readPlanningData_(siteKey);
  const rows = data.rows;
  const headers = data.headers;
  const spaces = getDynamicSpaceHeadersFromSheet_(siteKey, headers);

  const validRows = rows.filter(function(r) {
    return r["Date N"] instanceof Date;
  });

  const courseRows = validRows.filter(function(r) {
    return isCourseRow_(siteKey, r["Evénement + Heure"], r["Type"]);
  });

  const eventRows = validRows.filter(function(r) {
    const hasLabel = String(r["Evénement + Heure"] || "").trim() !== "";
    return hasLabel && !isCourseRow_(siteKey, r["Evénement + Heure"], r["Type"]);
  });

  const occupiedDays = new Set(
    validRows
      .filter(function(r) {
        return cleanText_(r["Evénement + Heure"]);
      })
      .map(function(r) {
        return formatDayKey_(r["Date N"]);
      })
  );

  const byMonth = {};
  const byWeek = {};
  const byManager = {};
  const bySpace = {};

  spaces.forEach(function(s) {
    bySpace[s] = 0;
  });

  validRows.forEach(function(r) {
    const d = r["Date N"];
    byMonth[formatMonthKey_(d)] = (byMonth[formatMonthKey_(d)] || 0) + 1;
    byWeek[formatWeekKey_(d)] = (byWeek[formatWeekKey_(d)] || 0) + 1;

    const manager = cleanText_(r["Gestion"]) || "(vide)";
    byManager[manager] = (byManager[manager] || 0) + 1;

    spaces.forEach(function(s) {
      if (r[s] === "X") bySpace[s] = (bySpace[s] || 0) + 1;
    });
  });

  let row = 1;
  sh.getRange(row++, 1)
    .setValue("DASHBOARD " + getSiteConfig_(siteKey).label.toUpperCase())
    .setFontWeight("bold")
    .setFontSize(14);

  sh.getRange(row, 1, 6, 2).setValues([
    ["Total lignes", validRows.length],
    ["Courses", courseRows.length],
    ["Evénements", eventRows.length],
    ["Jours occupés", occupiedDays.size],
    ["Espaces détectés", spaces.length],
    ["Responsables distincts", Object.keys(byManager).length]
  ]);
  row += 8;

  sh.getRange(row++, 1).setValue("Répartition mensuelle").setFontWeight("bold");
  const monthData = Object.keys(byMonth).sort().map(function(k) {
    return [k, byMonth[k]];
  });
  if (monthData.length) {
    sh.getRange(row, 1, monthData.length, 2).setValues(monthData);
  }
  row += Math.max(2, monthData.length + 2);

  sh.getRange(row++, 1).setValue("Top responsables").setFontWeight("bold");
  const managerData = Object.keys(byManager)
    .map(function(k) { return [k, byManager[k]]; })
    .sort(function(a, b) { return b[1] - a[1]; });

  if (managerData.length) {
    sh.getRange(row, 1, managerData.length, 2).setValues(managerData);
  }
  row += Math.max(2, managerData.length + 2);

  sh.getRange(row++, 1).setValue("Top espaces").setFontWeight("bold");
  const spaceData = Object.keys(bySpace)
    .map(function(k) { return [k, bySpace[k]]; })
    .sort(function(a, b) { return b[1] - a[1]; });

  if (spaceData.length) {
    sh.getRange(row, 1, spaceData.length, 2).setValues(spaceData);
  }

  sh.autoResizeColumns(1, 4);
}

// =======================
// RAPPORTS
// =======================

function buildPeriodSummary_(siteKey, rows) {
  const occupiedDays = new Set(
    rows
      .filter(function(r) { return cleanText_(r["Evénement + Heure"]); })
      .map(function(r) { return formatDayKey_(r["Date N"]); })
  );

  const courses = rows.filter(function(r) {
    return isCourseRow_(siteKey, r["Evénement + Heure"], r["Type"]);
  }).length;

  const events = rows.filter(function(r) {
    const hasLabel = String(r["Evénement + Heure"] || "").trim() !== "";
    return hasLabel && !isCourseRow_(siteKey, r["Evénement + Heure"], r["Type"]);
  }).length;

  return [
    ["Total lignes", rows.length],
    ["Courses", courses],
    ["Evénements", events],
    ["Jours occupés", occupiedDays.size]
  ];
}

function rapportParEspace_(siteKey, espace, dateDebut, dateFin) {
  const sh = ensureSheetByName_("RAPPORT_" + siteKey + "_ESPACES");
  sh.clear();

  const data = readPlanningData_(siteKey);
  const startDate = parseDateFlexible_(dateDebut);
  const endDate = parseDateFlexible_(dateFin);
  if (!startDate || !endDate) throw new Error("Dates invalides");

  const filtered = filterRowsByDate_(data.rows, startDate, endDate).filter(function(r) {
    return r[espace] === "X";
  });

  sh.getRange(1, 1).setValue("RAPPORT ESPACE");
  sh.getRange(2, 1, 4, 2).setValues([
    ["Site", siteKey],
    ["Espace", espace],
    ["Date début", formatDateFr_(startDate)],
    ["Date fin", formatDateFr_(endDate)]
  ]);

  if (filtered.length) {
    const exportRows = filtered.map(function(r) {
      return [
        r["Date N"],
        r["Evénement + Heure"],
        r["Gestion"],
        r["Type"],
        r["PAX"]
      ];
    });
    sh.getRange(7, 1, 1, 5).setValues([["Date", "Evénement + Heure", "Gestion", "Type", "PAX"]]);
    sh.getRange(8, 1, exportRows.length, 5).setValues(exportRows);
    sh.getRange(8, 1, exportRows.length, 1).setNumberFormat('[$-fr]dddd d mmmm yyyy');
  }

  sh.autoResizeColumns(1, 5);
}

function rapportParResponsable_(siteKey, responsable, dateDebut, dateFin) {
  const sh = ensureSheetByName_("RAPPORT_" + siteKey + "_RESPONSABLES");
  sh.clear();

  const data = readPlanningData_(siteKey);
  const startDate = parseDateFlexible_(dateDebut);
  const endDate = parseDateFlexible_(dateFin);
  if (!startDate || !endDate) throw new Error("Dates invalides");

  const respNorm = normalizeText_(responsable);

  const filtered = filterRowsByDate_(data.rows, startDate, endDate)
    .filter(function(r) { return normalizeText_(r["Gestion"]) === respNorm; });

  sh.getRange(1, 1).setValue("RAPPORT RESPONSABLE");
  sh.getRange(2, 1, 4, 2).setValues([
    ["Site", siteKey],
    ["Responsable", responsable],
    ["Date début", formatDateFr_(startDate)],
    ["Date fin", formatDateFr_(endDate)]
  ]);

  if (filtered.length) {
    const dynamicSpaces = getDynamicSpaceHeadersFromSheet_(siteKey, data.headers);
    const exportRows = filtered.map(function(r) {
      const usedSpaces = dynamicSpaces.filter(function(s) { return r[s] === "X"; }).join(", ");
      return [
        r["Date N"],
        r["Evénement + Heure"],
        r["Type"],
        r["PAX"],
        usedSpaces
      ];
    });

    sh.getRange(7, 1, 1, 5).setValues([["Date", "Evénement + Heure", "Type", "PAX", "Espaces"]]);
    sh.getRange(8, 1, exportRows.length, 5).setValues(exportRows);
    sh.getRange(8, 1, exportRows.length, 1).setNumberFormat('[$-fr]dddd d mmmm yyyy');
  }

  sh.autoResizeColumns(1, 5);
}

function rapportMensuel_(siteKey, annee, mois) {
  const sh = ensureSheetByName_("RAPPORT_" + siteKey + "_PERIODES");
  sh.clear();

  const range = getMonthRange_(annee, mois);
  const rows = filterRowsByDate_(readPlanningData_(siteKey).rows, range.start, range.end);

  sh.getRange(1, 1).setValue("RAPPORT MENSUEL");
  sh.getRange(2, 1, 4, 2).setValues([
    ["Site", siteKey],
    ["Année", annee],
    ["Mois", mois],
    ["Période", formatDateFr_(range.start) + " au " + formatDateFr_(range.end)]
  ]);

  const summary = buildPeriodSummary_(siteKey, rows);
  sh.getRange(7, 1, summary.length, 2).setValues(summary);

  if (rows.length) {
    const exportRows = rows.map(function(r) {
      return [
        r["Date N"],
        r["Evénement + Heure"],
        r["Gestion"],
        r["Type"],
        r["PAX"]
      ];
    });
    sh.getRange(14, 1, 1, 5).setValues([["Date", "Evénement + Heure", "Gestion", "Type", "PAX"]]);
    sh.getRange(15, 1, exportRows.length, 5).setValues(exportRows);
    sh.getRange(15, 1, exportRows.length, 1).setNumberFormat('[$-fr]dddd d mmmm yyyy');
  }

  sh.autoResizeColumns(1, 5);
}

function rapportAnnuel_(siteKey, annee) {
  const sh = ensureSheetByName_("RAPPORT_" + siteKey + "_PERIODES");
  sh.clear();

  const range = getYearRange_(annee);
  const rows = filterRowsByDate_(readPlanningData_(siteKey).rows, range.start, range.end);

  sh.getRange(1, 1).setValue("RAPPORT ANNUEL");
  sh.getRange(2, 1, 3, 2).setValues([
    ["Site", siteKey],
    ["Année", annee],
    ["Période", formatDateFr_(range.start) + " au " + formatDateFr_(range.end)]
  ]);

  const summary = buildPeriodSummary_(siteKey, rows);
  sh.getRange(6, 1, summary.length, 2).setValues(summary);

  const byMonth = {};
  rows.forEach(function(r) {
    const d = r["Date N"];
    byMonth[formatMonthKey_(d)] = (byMonth[formatMonthKey_(d)] || 0) + 1;
  });

  const monthRows = Object.keys(byMonth).sort().map(function(k) { return [k, byMonth[k]]; });
  if (monthRows.length) {
    sh.getRange(13, 1, 1, 2).setValues([["Mois", "Lignes"]]);
    sh.getRange(14, 1, monthRows.length, 2).setValues(monthRows);
  }

  sh.autoResizeColumns(1, 5);
}

// =======================
// ALERTES / CONFLITS
// =======================

function verifierConflits_(siteKey) {
  const sh = getAlertsSheet_(siteKey);
  sh.clear();

  const data = readPlanningData_(siteKey);
  const headers = data.headers;
  const rows = data.rows;
  const spaces = getDynamicSpaceHeadersFromSheet_(siteKey, headers);

  const alerts = [];
  const occupancy = {};

  rows.forEach(function(r) {
    const d = r["Date N"];
    if (!(d instanceof Date)) return;

    const keyDay = formatDayKey_(d);
    const id = r["ID_TECH"] || "";
    const type = isCourseRow_(siteKey, r["Evénement + Heure"], r["Type"])
      ? "Course"
      : "Evénement";

    const eventLabel = r["Evénement + Heure"] || "(vide)";

    if (!cleanText_(r["Gestion"]) && cleanText_(r["Evénement + Heure"])) {
      alerts.push([formatDateFr_(d), "GESTION MANQUANTE", eventLabel, type, id]);
    }

    let hasSpace = false;

    spaces.forEach(function(s) {
      if (r[s] === "X") {
        hasSpace = true;
        const occKey = keyDay + "||" + s;
        if (!occupancy[occKey]) occupancy[occKey] = [];
        occupancy[occKey].push(eventLabel + " [" + id + "]");
      }
    });

    if (!hasSpace && cleanText_(r["Evénement + Heure"])) {
      alerts.push([formatDateFr_(d), "ESPACE MANQUANT", eventLabel, type, id]);
    }
  });

  Object.keys(occupancy).forEach(function(k) {
    if (occupancy[k].length > 1) {
      const parts = k.split("||");
      alerts.push([parts[0], "DOUBLE OCCUPATION", parts[1], occupancy[k].join(" | "), ""]);
    }
  });

  sh.getRange(1, 1).setValue("ALERTES " + getSiteConfig_(siteKey).label.toUpperCase()).setFontWeight("bold");
  sh.getRange(2, 1, 1, 5).setValues([["Date", "Type alerte", "Objet", "Détail", "ID_TECH"]]);

  if (alerts.length) {
    sh.getRange(3, 1, alerts.length, 5).setValues(alerts);
  }

  sh.autoResizeColumns(1, 5);
}

// =======================
// RUN GLOBAL
// =======================

function runAllForSite_(siteKey) {
  try {
    const result = synchroniserCalendriersVersFeuille(siteKey);
    genererDashboard_(siteKey);
    verifierConflits_(siteKey);

    SpreadsheetApp.getUi().alert(
      "Mise à jour terminée - " + result.site + "\n\n" +
      "Lignes : " + result.rows + "\n" +
      "Espaces : " + result.spaces + "\n" +
      "Ajouts : " + result.added + "\n" +
      "Modifications : " + result.updated + "\n" +
      "Suppressions : " + result.deleted
    );
  } catch (e) {
    const message =
      "Erreur pendant la mise à jour du site " + siteKey + "\n\n" +
      (e && e.message ? e.message : e);

    Logger.log(message);
    SpreadsheetApp.getUi().alert(message);
  }
}
